# CHOUHAN STAR ⭐ - Security

**JAI SHRI RAM - Personal Lifetime Build**

A sovereign, privacy-first Android security and aura application built exclusively for Commander Dayaram Chouhan.

---

## 📥 Download & Install
1. Open the [Releases](https://github.com/dayaramchouhan723/CHOUHAN-STAR-Security/releases) section.
2. Download **`app-release.apk`** (or `CHOUHAN_STAR_Lifetime_Personal.apk`).
3. On your Android phone, enable **"Install unknown apps"** / Unknown Sources for your browser/file manager.
4. Open the downloaded APK and tap **Install** — Lifetime Free Sovereign Access.

---

## 🛡️ Features — 12 Screens Original
1. **Command Dashboard (`DashboardScreen`)**: Real-time threat shield, 1-tap emergency lock, intruder telemetry.
2. **Aura Control (`AuraControlScreen`)**: 4 glowing wireframe star icon variants (Crimson, Gold, Cyan, Emerald) and dynamic live wallpapers.
3. **GF Mode Scold Engine (`GfModeScreen`)**: Instant Hinglish audio scolds ("Khabardar phone chhua toh!"), vibration burst, and stealth intruder selfie.
4. **Touch Guard Siren (`TouchGuardScreen`)**: High-precision accelerometer theft detection with armed siren and volume control.
5. **App Lock Engine (`AppLockScreen`)**: Local PIN + Biometric app lock with individual app toggles.
6. **Face Setup (`FaceSetupScreen`)**: 3-angle local facial biometric enrollment using front camera.
7. **API & Cloud Vault (`ApiScreen`)**: Hardware-encrypted API keys (OpenAI, Gemini, Webhook) stored securely via Android Keystore.
8. **World Model Engine (`WorldModelScreen`)**: On-device activity pattern learning, trusted contacts, and device profiling.
9. **Triggers Hub (`TriggersScreen` & `TriggersHubScreen`)**: 77+ custom hardware & automation triggers.
10. **System Notifications & Storage (`NotificationsScreen`)**: Call announcements and local cache cleaner.
11. **Voice Personality & TTS (`PersonalityVoiceScreen`)**: Dabang Guardian, Royal Rajputana, and Cyber Commander voice engines.
12. **SpeechRecognizer Wake Word ("Hey Myra")**: Continuous on-device voice wake detection via `SpeechRecognizer` with live audio waveform visualizer and voice commands ("lock phone", "arm guard", "status report", "activate crimson aura").
13. **Profile & Lifetime License (`ProfilePremiumScreen`)**: Lifetime personal build certificate and zero-payment status.

---

## 🔒 Security & Privacy Invariants
- **No Internet Required for Core Security**: All alarms, sirens, touch guards, app locks, and scold engines run 100% offline on-device.
- **Strict Local Photo Privacy**: Intruder snapshots captured by GF Mode or Touch Guard are saved strictly to the local device storage (`Pictures/CHOUHAN_STAR/`) and are **never** uploaded to any cloud server.

---

## 📦 Source Code & Assets
- Full source code included in the `main` branch and in `CHOUHAN_STAR_Source.zip` attached to the release.
- Pre-built signed APKs:
  - `app-release.apk`
  - `app-debug.apk`
  - `CHOUHAN_STAR_Lifetime_Personal.apk`

---
*॥ JAI SHRI RAM ॥*
