package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.viewmodel.StarSecurityViewModel

private val DarkBg = Color(0xFF0A0A0A)
private val CardBg = Color(0xFF1A1A1A)
private val CrimsonAura = Color(0xFFE53935)
private val TextGrey = Color(0xFFA0A0A0)

@Composable
fun ApiScreen(
    viewModel: StarSecurityViewModel,
    onNavigateBack: () -> Unit
) {
    val uiState by viewModel.uiState.collectAsState()

    var openAiInput by remember(uiState.openAiKey) { mutableStateOf(uiState.openAiKey) }
    var geminiInput by remember(uiState.geminiKey) { mutableStateOf(uiState.geminiKey) }
    var customUrlInput by remember(uiState.customApiUrl) { mutableStateOf(uiState.customApiUrl) }

    var isOpenAiVisible by remember { mutableStateOf(false) }
    var isGeminiVisible by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(DarkBg)
            .padding(16.dp)
            .testTag("api_screen")
    ) {
        // Top Bar
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.fillMaxWidth()
        ) {
            IconButton(
                onClick = onNavigateBack,
                modifier = Modifier.testTag("api_back_button")
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = "Back",
                    tint = Color.White
                )
            }
            Spacer(modifier = Modifier.width(8.dp))
            Column {
                Text(
                    text = "API & Cloud",
                    color = Color.White,
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "External services connect",
                    color = TextGrey,
                    fontSize = 12.sp
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Card 1: API Keys
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("api_keys_card"),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = CardBg),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF2A2A2A))
                ) {
                    Column(modifier = Modifier.padding(18.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(imageVector = Icons.Default.Key, contentDescription = null, tint = CrimsonAura, modifier = Modifier.size(20.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "API Keys",
                                color = Color.White,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        // OpenAI Key Field
                        Text(text = "OpenAI API Key", color = TextGrey, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                        Spacer(modifier = Modifier.height(4.dp))
                        OutlinedTextField(
                            value = openAiInput,
                            onValueChange = { openAiInput = it },
                            placeholder = { Text("sk-proj-...", color = Color(0xFF555555), fontSize = 12.sp) },
                            visualTransformation = if (isOpenAiVisible) VisualTransformation.None else PasswordVisualTransformation(),
                            trailingIcon = {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    IconButton(onClick = { isOpenAiVisible = !isOpenAiVisible }) {
                                        Icon(
                                            imageVector = if (isOpenAiVisible) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                            contentDescription = null,
                                            tint = TextGrey,
                                            modifier = Modifier.size(18.dp)
                                        )
                                    }
                                    IconButton(onClick = { viewModel.saveOpenAiKey(openAiInput) }) {
                                        Icon(
                                            imageVector = Icons.Default.Save,
                                            contentDescription = "Save OpenAI Key",
                                            tint = CrimsonAura,
                                            modifier = Modifier.size(18.dp)
                                        )
                                    }
                                }
                            },
                            modifier = Modifier.fillMaxWidth().testTag("openai_key_field"),
                            shape = RoundedCornerShape(12.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = CrimsonAura,
                                unfocusedBorderColor = Color(0xFF333333),
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White
                            )
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        // Gemini Key Field
                        Text(text = "Gemini API Key", color = TextGrey, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                        Spacer(modifier = Modifier.height(4.dp))
                        OutlinedTextField(
                            value = geminiInput,
                            onValueChange = { geminiInput = it },
                            placeholder = { Text("AIzaSy...", color = Color(0xFF555555), fontSize = 12.sp) },
                            visualTransformation = if (isGeminiVisible) VisualTransformation.None else PasswordVisualTransformation(),
                            trailingIcon = {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    IconButton(onClick = { isGeminiVisible = !isGeminiVisible }) {
                                        Icon(
                                            imageVector = if (isGeminiVisible) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                            contentDescription = null,
                                            tint = TextGrey,
                                            modifier = Modifier.size(18.dp)
                                        )
                                    }
                                    IconButton(onClick = { viewModel.saveGeminiKey(geminiInput) }) {
                                        Icon(
                                            imageVector = Icons.Default.Save,
                                            contentDescription = "Save Gemini Key",
                                            tint = CrimsonAura,
                                            modifier = Modifier.size(18.dp)
                                        )
                                    }
                                }
                            },
                            modifier = Modifier.fillMaxWidth().testTag("gemini_key_field"),
                            shape = RoundedCornerShape(12.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = CrimsonAura,
                                unfocusedBorderColor = Color(0xFF333333),
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White
                            )
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        // Custom API URL Field
                        Text(text = "Custom API URL", color = TextGrey, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                        Spacer(modifier = Modifier.height(4.dp))
                        OutlinedTextField(
                            value = customUrlInput,
                            onValueChange = { customUrlInput = it },
                            placeholder = { Text("https://api.yourdomain.com/v1", color = Color(0xFF555555), fontSize = 12.sp) },
                            trailingIcon = {
                                IconButton(onClick = { viewModel.saveCustomApiUrl(customUrlInput) }) {
                                    Icon(
                                        imageVector = Icons.Default.Save,
                                        contentDescription = "Save Custom URL",
                                        tint = CrimsonAura,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                            },
                            modifier = Modifier.fillMaxWidth().testTag("custom_api_url_field"),
                            shape = RoundedCornerShape(12.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = CrimsonAura,
                                unfocusedBorderColor = Color(0xFF333333),
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White
                            )
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(imageVector = Icons.Default.Lock, contentDescription = null, tint = TextGrey, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "All keys saved local encrypted",
                                color = TextGrey,
                                fontSize = 12.sp
                            )
                        }
                    }
                }
            }

            // Card 2: Connections Mini API
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("connections_mini_api_card"),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = CardBg),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF2A2A2A))
                ) {
                    Column(modifier = Modifier.padding(18.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(imageVector = Icons.Default.Link, contentDescription = null, tint = CrimsonAura, modifier = Modifier.size(20.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "External Integrations",
                                color = Color.White,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        // WhatsApp connector
                        ConnectorRow(
                            title = "WhatsApp Connector",
                            subtitle = "Direct emergency messaging bridge",
                            checked = uiState.whatsappConnector,
                            onCheckedChange = { viewModel.toggleWhatsappConnector(it) },
                            hasConfig = true,
                            testTag = "whatsapp_connector_toggle"
                        )

                        Spacer(modifier = Modifier.height(14.dp))

                        // Gmail connector
                        ConnectorRow(
                            title = "Gmail Connector",
                            subtitle = "Automated security report emails",
                            checked = uiState.gmailConnector,
                            onCheckedChange = { viewModel.toggleGmailConnector(it) },
                            hasConfig = false,
                            testTag = "gmail_connector_toggle"
                        )

                        Spacer(modifier = Modifier.height(14.dp))

                        // Calendar connector
                        ConnectorRow(
                            title = "Calendar Connector",
                            subtitle = "Scheduled guard sync & events",
                            checked = uiState.calendarConnector,
                            onCheckedChange = { viewModel.toggleCalendarConnector(it) },
                            hasConfig = false,
                            testTag = "calendar_connector_toggle"
                        )

                        Spacer(modifier = Modifier.height(16.dp))

                        Text(
                            text = "Connect apps for automation",
                            color = TextGrey,
                            fontSize = 12.sp
                        )
                    }
                }
            }

            item {
                Spacer(modifier = Modifier.height(24.dp))
            }
        }
    }
}

@Composable
private fun ConnectorRow(
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
    hasConfig: Boolean,
    testTag: String
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(text = title, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold)
            Text(text = subtitle, color = TextGrey, fontSize = 11.sp)
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            if (hasConfig) {
                IconButton(onClick = { /* Open config */ }) {
                    Icon(imageVector = Icons.Default.Settings, contentDescription = "Configure", tint = TextGrey, modifier = Modifier.size(18.dp))
                }
            }
            Switch(
                checked = checked,
                onCheckedChange = onCheckedChange,
                colors = SwitchDefaults.colors(
                    checkedThumbColor = Color.White,
                    checkedTrackColor = CrimsonAura,
                    uncheckedThumbColor = TextGrey,
                    uncheckedTrackColor = Color(0xFF262626)
                ),
                modifier = Modifier.testTag(testTag)
            )
        }
    }
}
